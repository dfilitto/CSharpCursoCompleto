﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operadores
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Programa que efetua todas as operações matemáticas
            /*
            Console.WriteLine("Operadores");
            Console.Write("10+10 = ");
            Console.WriteLine(10+10);

            Console.Write("10-10 = ");
            Console.WriteLine(10 - 10);

            Console.Write("10*10 = ");
            Console.WriteLine(10 * 10);

            Console.Write("10/10 = ");
            Console.WriteLine(10 / 10);

            Console.Write("10%10 = ");
            Console.WriteLine(10 % 10);

            Console.Write("10 < 10 = ");
            Console.WriteLine(10 < 10);

            Console.Write("10 <= 10 = ");
            Console.WriteLine(10 <= 10);

            Console.Write("10 > 10 = ");
            Console.WriteLine(10 > 10);

            Console.Write("10 >= 10 = ");
            Console.WriteLine(10 >= 10);

            Console.Write("10 == 10 = ");
            Console.WriteLine(10 == 10);

            Console.Write("10 != 10 = ");
            Console.WriteLine(10 != 10);
            */

            Console.Write("5 / 2 = ");
            Console.WriteLine(5/2);
            Console.Write("5 % 2 = ");
            Console.WriteLine(5 % 2);
            Console.Write("5 != 2 = ");
            Console.WriteLine(5 != 2);


            Console.ReadLine();
        }
    }
}
