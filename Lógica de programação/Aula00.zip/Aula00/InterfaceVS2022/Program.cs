﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceVS2022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Alo Mundo!!!!!");
            Console.ReadKey();
        }
    }
}
