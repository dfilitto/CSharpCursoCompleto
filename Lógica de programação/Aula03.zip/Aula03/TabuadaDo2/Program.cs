﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TabuadaDo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tabuada do 2");
            /*
            Console.Write("2 x 1 = ");
            Console.WriteLine(2 * 1);
            */
            Console.WriteLine("2 x 1 = " + (2 * 1));
            Console.WriteLine("2 x 2 = " + (2 * 2));
            Console.WriteLine("2 x 3 = " + (2 * 3));
            Console.WriteLine("2 x 4 = " + (2 * 4));
            Console.WriteLine("2 x 5 = " + (2 * 5));
            Console.WriteLine("2 x 6 = " + (2 * 6));
            Console.WriteLine("2 x 7 = " + (2 * 7));
            Console.WriteLine("2 x 8 = " + (2 * 8));
            Console.WriteLine("2 x 9 = " + (2 * 9));
            Console.WriteLine("2 x 10 = " + (2 * 10));
            Console.ReadKey();
        }
    }
}
