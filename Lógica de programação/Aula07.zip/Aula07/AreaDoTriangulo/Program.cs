﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaDoTriangulo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a = 0; //área
            double b = 0; //base
            double h = 0; //altura
            string entreda = "";

            Console.WriteLine("Área de um triângulo");
            Console.Write("Informe a base do triângulo: ");
            entreda = Console.ReadLine();
            b = Convert.ToDouble(entreda);

            Console.Write("Informe a altura do triângulo: ");
            entreda = Console.ReadLine();
            h = Convert.ToDouble(entreda);

            a = (b * h) / 2;

            Console.WriteLine("Área de um triângulo");
            Console.WriteLine("Base: " + b);
            Console.WriteLine("Altura: " + h);
            Console.WriteLine("Área: " + a);
            Console.ReadKey();
        }
    }
}
