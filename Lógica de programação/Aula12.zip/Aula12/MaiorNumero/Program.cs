﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaiorNumero
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            int maiorNumero = 0;

            Console.WriteLine("Programa que determina o maior número informado");
            Console.Write("Informe o 1º Número: ");
            n = Convert.ToInt32(Console.ReadLine());
            //maior número
            maiorNumero = n;
            Console.Write("Informe o 2º Número: ");
            n = Convert.ToInt32(Console.ReadLine());
            if(n > maiorNumero) {
                maiorNumero = n;
            }
            Console.Write("Informe o 3º Número: ");
            n = Convert.ToInt32(Console.ReadLine());
            if (n > maiorNumero)
            {
                maiorNumero = n;
            }
            Console.WriteLine("O maior número é {0}",maiorNumero);
            Console.ReadKey();
        }
    }
}
