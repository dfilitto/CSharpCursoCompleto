﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculoDaIdade
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int anoAtual = DateTime.Now.Year;
            int dtNasc = 0;
            int idade = 0;

            Console.WriteLine("Programa que calcula a Idade de uma pessoa");
            Console.Write("Qual é seu ano de nascimento: ");
            dtNasc = Convert.ToInt32(Console.ReadLine());

            //validar a data de nascimento
            idade = anoAtual - dtNasc;

            Console.WriteLine("Sua idade é {0} anos",idade);
            Console.ReadKey();
        }
    }
}
